import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;



public class MainTest {

	public MainTest() {
		// TODO Auto-generated constructor stub

	}

	static HashMap<String, ArrayList<String>>list=new HashMap<String, ArrayList<String>>();
	static ArrayList<ArrayList<String>> V =new ArrayList<ArrayList<String>>();

	static ArrayList<String> V1 =new ArrayList<String>();
	static ArrayList<String> V2 =new ArrayList<String>();
	static ArrayList<String> V3=new ArrayList<String>();
	static ArrayList<String> V4=new ArrayList<String>();
	static ArrayList<String> V5 =new ArrayList<String>();
	static int next=0;

	public static void MethodWithList() {
		V.add(V1);
		V.add(V2);
		V.add(V3);
		V.add(V4);
		V.add(V5);
		int i=1;
		for (ArrayList<String> val : V) {

			System.out.println("Node S"+i+": "+val.size());
		
		i++;
		}
	}
	public static void remplirlalist() {

		V1.add("A");
		V1.add("B");
		V1.add("C");
		V1.add("D");
		list.put("A", V1);

		V2.add("C");
		V2.add("D");
		list.put("B", V2);

		V3.add("A");
		V3.add("B");
		V3.add("D");
		V3.add("C");
		list.put("C", V3);

		V4.add("A");
		V4.add("B");
		V4.add("C");
		list.put("D", V4);
		list.put("H", V5);

	}

	public static void main(String[] args) {

		remplirlalist();
	MethodWithList();
		System.out.println("###########################");

		list.forEach((k,v) -> {
			
			System.out.println("Node: "+k+" list:"+v);

		});	
		System.out.println("###########################");
		list.forEach((k,v) -> {
			//value
			System.out.println("Node: "+k+" N�Arc+:"+v.size());
		//getNigatifArgs(k);
		System.out.println("---------------------------");

		});	

	}
	
	public static int getNigatifArgs(String val) {
		next=0;
		list.forEach((k,v) -> {
			if (v.contains(val)&&(val!=k)) {
				next++;
			}        
		});	 
		System.out.println("Node: "+val+" N�Arc-: "+next);
		return next;
	}



}
