import java.util.ArrayList;

public class complexiteClass {

	public complexiteClass() {
		// TODO Auto-generated constructor stub
	}
	
	public static 	ArrayList<Integer> list=new ArrayList<Integer>();
	public static 	ArrayList<Integer> listSize=new ArrayList<Integer>();

	public  static  ArrayList<Double> testComplexite() throws InterruptedException {

		ArrayList<Double> arrayList=new ArrayList<Double>();

		int k=1;
	while (k<=5) {

			 	for (int i = 1; i <= (10000); i++) {
				list.add(2);
			}
			
//########################################################################################################
			final double startTime = System.currentTimeMillis();
			listSize.add(list.size());

			//System.out.println("Value : "+list.size());

	Thread.sleep(50);
			final double endTime = System.currentTimeMillis();
//########################################################################################################
			double time = (Double) (endTime - startTime);
			
			arrayList.add(time);
					
		k++;
			}

		return arrayList ;
	}public  static  ArrayList<Double> testMyComplexite() throws InterruptedException {

		ArrayList<Double> arrayList=new ArrayList<Double>();

		int k=1;

		while (k<=5) {

			 	for (int i = 1; i <= (10000); i++) {
				list.add(200);
			}
			//listSize.add(list.size());
			
//########################################################################################################
			final double startTime = System.currentTimeMillis();

         listSize.add(getSize());

		//	System.out.println("Value : "+	getSize());

	//Thread.sleep(50);
			final double endTime = System.currentTimeMillis();
//########################################################################################################
			double time = (Double) (endTime - startTime);
			
			arrayList.add(time);

		
		k++;
			}

		return arrayList ;
	}
	
	public static int getSize() {
	int i=0;
		for (Integer val : list) {

			System.out.println();
		
		i++;
		}
		return i;
	}
}
