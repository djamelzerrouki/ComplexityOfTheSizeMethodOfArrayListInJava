
import java.io.FileNotFoundException;
import java.util.ArrayList;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;


public class complixiteMethSize extends Application {

	public complixiteMethSize() {
		// TODO Auto-generated constructor stub
	}

	public ArrayList<String> list;

	public Button button2;



	public ListView<String> listView;
	public ObservableList<String> observableList;
	private XYChart.Series series;


	@Override
	public void start(Stage primaryStage)throws Exception {
		BorderPane borderPaint=new BorderPane();

		button2=new Button("Afficher graphe");
		button2.setPrefHeight(37);
		button2.setOnAction(new EventHandler() {

			@Override
			public void handle(Event arg0) {


				try {
					Linchart(borderPaint);
				} catch (FileNotFoundException | InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
		});

		list=new ArrayList<String>();
		observableList=FXCollections.observableArrayList();

		listView =new ListView<String>(observableList);
		VBox vbox=new VBox(20);
		vbox.setPadding(new Insets(20));
		vbox.getChildren().addAll(listView,button2);
		VBox vbox2=new VBox();
		vbox2.setAlignment(Pos.CENTER);
		//	vbox2.setPadding(new Insets(20));
		borderPaint.setTop(vbox2);
		borderPaint.setCenter(vbox);

		Scene scene = new Scene(borderPaint,750,550);

		primaryStage.setScene(scene);
		primaryStage.show();
	}

	// methode de creation de Linchart

	public  void Linchart(BorderPane borderPaint) throws FileNotFoundException, InterruptedException {

		final NumberAxis xAxis = new NumberAxis();
		final NumberAxis yAxis = new NumberAxis();
		xAxis.setLabel("Size of list");
		yAxis.setLabel("Time");

		//creating the chart
		final LineChart<Number,Number> lineChart = new LineChart<Number,Number>(xAxis,yAxis);

		lineChart.setTitle("COMPLEXITY of Method , size()");
		//defining a series

		XYChart.Series series = new XYChart.Series();
		series.setName("Size of list with time");

		ArrayList<Double> arrayList=complexiteClass.testComplexite();
		ArrayList<Double> arrayList2=complexiteClass.testMyComplexite();


		int k=0;
		XYChart.Series series2 = new XYChart.Series();
		series2.setName("MYSize of list with time");
		observableList.clear();
		
		//###################################### testComplexite #################################################
		for (double val : arrayList) {
			observableList.add(complexiteClass.listSize.get(k)+" ==> "+val);
			series.getData().add(new XYChart.Data<Integer, Double>(complexiteClass.listSize.get(k),val));

			k++;
		}
		//####################################### testMyComplexite ################################################
		k=0;
		for (double val : arrayList2) {
			observableList.add(complexiteClass.listSize.get(k)+" ==> "+val);
			series2.getData().add(new XYChart.Data<Integer, Double>(complexiteClass.listSize.get(k),val));

			k++;
		}
		//########################################################################################################

		borderPaint.setLeft(lineChart);
		lineChart.getData().add(series);
		lineChart.getData().add(series2);
	}

	public static void main(String[] args) {

		launch(args);

	}	


}




